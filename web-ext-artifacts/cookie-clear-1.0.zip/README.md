"# auto-clear-cookie" 
