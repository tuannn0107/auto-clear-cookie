var prefs = {
    'clear_browser_data_dd': 0,
    'clear_browser_data_hh': 0,
    'clear_browser_data_mm': 10,
    'clear_browser_data_ss': 0,
};

// init
console.log('popup displayed');